import { ThemeProvider } from "next-themes";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Hero from "./sections/Hero";
import CorporateSlider from "./sections/CorporateSlider";
import Features from "./sections/Features";
import HowItWorks from "./sections/HowItWorks";
import Commercial from "./sections/Commercial";
import Help from "./sections/Help";
import About from "./sections/About";
import Contact from "./sections/Contact";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <TooltipProvider>
          <Toaster />
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
              <Hero />
              <CorporateSlider />
              <Features />
              <HowItWorks />
              <Commercial />
              <Help />
              <About />
              <Contact />
            </main>
            <Footer />
          </div>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
