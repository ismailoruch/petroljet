import { useState, useEffect } from "react";
import ThemeToggle from "./ThemeToggle";
import { Menu, X, Home, ListFilter, Settings, Building, HelpCircle, Info, Mail, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

type NavItem = {
  label: string;
  href: string;
  icon: React.ReactNode;
  dropdown?: { label: string; href: string }[];
};

const navItems: NavItem[] = [
  { label: "Ana Sayfa", href: "#hero", icon: <Home className="h-4 w-4 mr-2" /> },
  { label: "Özellikler", href: "#features", icon: <ListFilter className="h-4 w-4 mr-2" /> },
  { label: "Nasıl Çalışır", href: "#how-it-works", icon: <Settings className="h-4 w-4 mr-2" /> },
  { label: "Ticari", href: "#commercial", icon: <Building className="h-4 w-4 mr-2" /> },
  { 
    label: "Yardım", 
    href: "#help", 
    icon: <HelpCircle className="h-4 w-4 mr-2" />,
    dropdown: [{ label: "Sıkça Sorulan Sorular - SSS", href: "#faq" }]
  },
  { label: "Hakkımızda", href: "#about", icon: <Info className="h-4 w-4 mr-2" /> },
  { label: "İletişim", href: "#contact", icon: <Mail className="h-4 w-4 mr-2" /> },
];

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const isMobile = useIsMobile();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={cn(
      "fixed w-full bg-background z-50 transition-all duration-300",
      scrolled ? "border-b border-border shadow-sm py-2" : "py-4"
    )}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <a href="#hero" className="text-2xl font-bold">
            Petrol Jet
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            {navItems.map((item, index) => (
              !item.dropdown ? (
                <a 
                  key={index} 
                  href={item.href} 
                  className="nav-item bg-[#0c1014] text-white px-4 py-2 rounded-full flex items-center"
                  onClick={closeMenu}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </a>
              ) : (
                <DropdownMenu key={index}>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="nav-item bg-[#0c1014] text-white px-4 py-2 rounded-full flex items-center">
                      {item.icon}
                      <span>{item.label}</span>
                      <ChevronDown className="h-4 w-4 ml-2" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {item.dropdown.map((subItem, subIndex) => (
                      <DropdownMenuItem key={subIndex} asChild>
                        <a 
                          href={subItem.href}
                          className="cursor-pointer w-full"
                          onClick={closeMenu}
                        >
                          {subItem.label}
                        </a>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              )
            ))}
            
            <div className="flex items-center">
              <ThemeToggle />
            </div>
          </nav>

          {/* Mobile Navigation Button */}
          <div className="flex items-center md:hidden space-x-2">
            <ThemeToggle />
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleMenu}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobile && (
          <div className={cn(
            "md:hidden transition-all duration-300 overflow-hidden",
            isMenuOpen ? "max-h-[1000px] py-4 mt-4 border-t border-border" : "max-h-0"
          )}>
            <nav className="flex flex-col space-y-4">
              {navItems.map((item, index) => (
                <div key={index}>
                  <a
                    href={item.href}
                    className="nav-item bg-[#0c1014] text-white px-4 py-2 rounded-full flex items-center justify-center"
                    onClick={closeMenu}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </a>
                  
                  {item.dropdown && (
                    <div className="ml-8 mt-2 space-y-2">
                      {item.dropdown.map((subItem, subIndex) => (
                        <a
                          key={subIndex}
                          href={subItem.href}
                          className="nav-item flex items-center text-foreground"
                          onClick={closeMenu}
                        >
                          <ChevronDown className="h-3 w-3 mr-2 rotate-270" />
                          <span>{subItem.label}</span>
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}