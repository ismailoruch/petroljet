import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

// Language type definition
type Language = {
  code: string;
  name: string;
  flag: React.ReactNode;
};

// Professionally crafted Turkish flag SVG
const TurkishFlag = () => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 512 512" 
    className="w-full h-full"
    fill="none"
  >
    {/* Perfect circle red background */}
    <circle cx="256" cy="256" r="256" fill="#E30A17"/>
    
    {/* Precisely positioned crescent and star */}
    <g transform="translate(256, 256) scale(0.85)">
      {/* Crescent */}
      <circle cx="-63" cy="0" r="74" fill="#FFFFFF"/>
      <circle cx="-26" cy="0" r="64" fill="#E30A17"/>
      
      {/* Star - perfectly shaped 5-pointed star */}
      <path
        fill="#FFFFFF"
        d="M74,0 L85,-25 L112,-8 L94,-35 L118,-48 L88,-58 L98,-85 L74,-65 L50,-85 L60,-58 L30,-48 L54,-35 L36,-8 L63,-25 z"
      />
    </g>
  </svg>
);

const BritishFlag = () => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 512 512" 
    className="w-full h-full"
  >
    <circle cx="256" cy="256" r="256" fill="#012169"/>
    <path d="M256,100 L256,412" stroke="#fff" strokeWidth="60"/>
    <path d="M100,256 L412,256" stroke="#fff" strokeWidth="60"/>
    <path d="M100,100 L412,412 M412,100 L100,412" stroke="#fff" strokeWidth="40"/>
    <path d="M256,120 L256,392" stroke="#C8102E" strokeWidth="30"/>
    <path d="M120,256 L392,256" stroke="#C8102E" strokeWidth="30"/>
    <path d="M120,120 L392,392 M392,120 L120,392" stroke="#C8102E" strokeWidth="20"/>
  </svg>
);

// Available languages
const languages: Language[] = [
  {
    code: "tr",
    name: "Türkçe",
    flag: <TurkishFlag />
  },
  {
    code: "en",
    name: "English",
    flag: <BritishFlag />
  }
];

export default function LanguageSwitcher() {
  // Default to Turkish
  const [currentLanguage, setCurrentLanguage] = useState<Language>(languages[0]);

  // Change language handler
  const changeLanguage = (language: Language) => {
    setCurrentLanguage(language);
    // Here you would implement actual language change functionality
    // such as using i18n library or context API
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {/* Exact Papara-style language selector */}
        <Button 
          variant="ghost" 
          className="h-9 pl-2 pr-2.5 py-0 flex items-center gap-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 border border-gray-200 dark:border-gray-700"
          aria-label="Change language"
        >
          {/* Perfect circle for flag with exact size to match theme toggle */}
          <div className="flex items-center justify-center w-6 h-6 rounded-full overflow-hidden shrink-0">
            {currentLanguage.flag}
          </div>
          {/* Lighter text color as specified */}
          <span className="text-xs font-medium text-[#aaaaaa]">{currentLanguage.name}</span>
          <ChevronDown className="h-3 w-3 text-[#aaaaaa]" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[120px] rounded-lg overflow-hidden shadow-md p-1">
        {languages.map((language) => (
          <DropdownMenuItem 
            key={language.code}
            onClick={() => changeLanguage(language)}
            className={`flex items-center gap-2 cursor-pointer py-1.5 px-2 rounded-md ${
              currentLanguage.code === language.code ? "bg-muted" : ""
            }`}
          >
            <span className="flex items-center justify-center h-5 w-5 shrink-0 rounded-full overflow-hidden">
              {language.flag}
            </span>
            <span className="text-xs">{language.name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}