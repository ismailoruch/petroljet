import { Facebook, Twitter, Linkedin, Instagram, MapPin, Phone, Mail, Clock } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#1e2a32] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Petrol Jet</h3>
            <p className="text-gray-400 mb-4">Modern çözümler ile geleceğe adım atın.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-[#eebd32] transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#eebd32] transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#eebd32] transition-colors">
                <Linkedin size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#eebd32] transition-colors">
                <Instagram size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Hızlı Bağlantılar</h3>
            <ul className="space-y-2">
              <li><a href="#hero" className="text-gray-400 hover:text-[#eebd32] transition-colors">Ana Sayfa</a></li>
              <li><a href="#features" className="text-gray-400 hover:text-[#eebd32] transition-colors">Özellikler</a></li>
              <li><a href="#how-it-works" className="text-gray-400 hover:text-[#eebd32] transition-colors">Nasıl Çalışır</a></li>
              <li><a href="#commercial" className="text-gray-400 hover:text-[#eebd32] transition-colors">Ticari</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Destek</h3>
            <ul className="space-y-2">
              <li><a href="#help" className="text-gray-400 hover:text-[#eebd32] transition-colors">Yardım</a></li>
              <li><a href="#faq" className="text-gray-400 hover:text-[#eebd32] transition-colors">SSS</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-[#eebd32] transition-colors">İletişim</a></li>
              <li><a href="#" className="text-gray-400 hover:text-[#eebd32] transition-colors">Gizlilik Politikası</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">İletişim</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mt-1 mr-2 text-[#eebd32]" />
                <span className="text-gray-400">Atatürk Caddesi, No: 123, Levent, İstanbul</span>
              </li>
              <li className="flex items-start">
                <Phone className="h-5 w-5 mt-1 mr-2 text-[#eebd32]" />
                <span className="text-gray-400">+90 (212) 123 45 67</span>
              </li>
              <li className="flex items-start">
                <Mail className="h-5 w-5 mt-1 mr-2 text-[#eebd32]" />
                <span className="text-gray-400">info@petroljet.com</span>
              </li>
              <li className="flex items-start">
                <Clock className="h-5 w-5 mt-1 mr-2 text-[#eebd32]" />
                <span className="text-gray-400">
                  Pazartesi - Cuma: 09:00 - 18:00<br />
                  Hafta sonu: Kapalı
                </span>
              </li>
            </ul>
          </div>
        </div>
        
        <Separator className="my-8 bg-gray-700" />
        
        <div className="text-center">
          <p className="text-gray-400">&copy; {currentYear} Petrol Jet. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  );
}
