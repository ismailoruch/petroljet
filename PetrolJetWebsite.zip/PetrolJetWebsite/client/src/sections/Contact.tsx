import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, you would submit this data to your backend
    // For now, we'll just show a success toast
    toast({
      title: "Mesajınız gönderildi!",
      description: "En kısa sürede size dönüş yapacağız.",
    });
    
    // Reset form
    setFormData({
      name: "",
      email: "",
      subject: "",
      message: ""
    });
  };

  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">İletişim</h2>
          <p className="section-subheading">
            Sorularınız veya iş birliği teklifleriniz için bizimle iletişime geçin.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <Label htmlFor="name" className="mb-2">Ad Soyad</Label>
                <Input 
                  id="name"
                  name="name"
                  placeholder="Adınız Soyadınız"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="rounded-md"
                />
              </div>
              
              <div className="mb-6">
                <Label htmlFor="email" className="mb-2">E-posta</Label>
                <Input 
                  id="email"
                  name="email"
                  type="email"
                  placeholder="ornek@sirket.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="rounded-md"
                />
              </div>
              
              <div className="mb-6">
                <Label htmlFor="subject" className="mb-2">Konu</Label>
                <Input 
                  id="subject"
                  name="subject"
                  placeholder="Mesajınızın konusu"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="rounded-md"
                />
              </div>
              
              <div className="mb-6">
                <Label htmlFor="message" className="mb-2">Mesaj</Label>
                <Textarea 
                  id="message"
                  name="message"
                  placeholder="Mesajınızı buraya yazın..."
                  rows={5}
                  value={formData.message}
                  onChange={handleChange}
                  required
                  className="rounded-md"
                />
              </div>
              
              <Button 
                type="submit" 
                className="bg-[#eebd32] hover:bg-[#eebd32]/90 text-[#0c1014] rounded-full"
              >
                Gönder
              </Button>
            </form>
          </div>
          
          <div className="md:w-1/2">
            <Card className="bg-background">
              <CardHeader>
                <CardTitle className="text-2xl">İletişim Bilgilerimiz</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 mt-1 mr-4 text-[#eebd32]" />
                    <div>
                      <h4 className="text-lg font-medium mb-1">Adres</h4>
                      <p className="text-muted-foreground">
                        Atatürk Caddesi, No: 123<br />
                        Levent, İstanbul, Türkiye
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 mt-1 mr-4 text-[#eebd32]" />
                    <div>
                      <h4 className="text-lg font-medium mb-1">Telefon</h4>
                      <p className="text-muted-foreground">
                        +90 (212) 123 45 67
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Mail className="h-5 w-5 mt-1 mr-4 text-[#eebd32]" />
                    <div>
                      <h4 className="text-lg font-medium mb-1">E-posta</h4>
                      <p className="text-muted-foreground">
                        info@petroljet.com
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Clock className="h-5 w-5 mt-1 mr-4 text-[#eebd32]" />
                    <div>
                      <h4 className="text-lg font-medium mb-1">Çalışma Saatleri</h4>
                      <p className="text-muted-foreground">
                        Pazartesi - Cuma: 09:00 - 18:00<br />
                        Hafta sonu: Kapalı
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
