import { Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">Hakkımızda</h2>
          <p className="section-subheading">
            Petrol Jet ekibi olarak vizyonumuz ve misyonumuz.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <h3 className="text-2xl font-semibold mb-4">Biz Kimiz?</h3>
            <p className="text-muted-foreground mb-6">
              Petrol Jet, 2015 yılında teknoloji tutkunu bir ekip tarafından kuruldu. Amacımız, işletmelerin dijital dönüşüm süreçlerinde yanlarında olmak ve modern çözümler sunmaktır.
            </p>
            <p className="text-muted-foreground mb-6">
              Yenilikçi yaklaşımımız ve müşteri odaklı hizmet anlayışımızla sektörde fark yaratıyoruz. Ekibimiz, alanında uzman profesyonellerden oluşmaktadır.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-[#eebd32] hover:text-[#eebd32]/80">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-[#eebd32] hover:text-[#eebd32]/80">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-[#eebd32] hover:text-[#eebd32]/80">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-[#eebd32] hover:text-[#eebd32]/80">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          <div className="md:w-1/2 grid grid-cols-2 gap-4">
            <img 
              src="https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
              alt="Team member" 
              className="rounded-lg shadow-md w-full object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1573497701240-345a400c6d3a?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
              alt="Team member" 
              className="rounded-lg shadow-md w-full object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1573496528736-f37a3fb1d8b7?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
              alt="Team member" 
              className="rounded-lg shadow-md w-full object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1573497019418-b400bb3ab074?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
              alt="Team member" 
              className="rounded-lg shadow-md w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
