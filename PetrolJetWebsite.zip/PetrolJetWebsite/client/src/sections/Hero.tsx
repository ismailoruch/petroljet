import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

type Slogan = {
  text: string;
  color: string;
};

export default function Hero() {
  // Slogans with exact colors as specified
  const slogans: Slogan[] = [
    { text: "Yakıtın Cepte", color: "#cd2033" },        // Red
    { text: "Kampanyalar Cepte", color: "#e94f8b" },    // Pink
    { text: "Anında Fulle", color: "#c14a1d" },         // Orange
    { text: "Tasarruf Et", color: "#2ecc71" }           // Green
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  // Simple, clean animation effect for slogan rotation
  useEffect(() => {
    let timeoutId: number;
    
    // Main rotation interval
    const rotationInterval = setInterval(() => {
      // First fade out the current slogan
      setIsVisible(false);
      
      // Then wait for the fade-out animation to complete
      timeoutId = window.setTimeout(() => {
        // Update to the next slogan while it's invisible
        setCurrentIndex((prevIndex) => (prevIndex + 1) % slogans.length);
        
        // Then make the new slogan visible
        setIsVisible(true);
      }, 1000); // Match the slower transition duration (1 second) in CSS
    }, 4000); // Total time each slogan is displayed
    
    // Clean up both timers
    return () => {
      clearInterval(rotationInterval);
      clearTimeout(timeoutId);
    };
  }, [slogans.length]);

  return (
    <section id="hero" className="pt-24 pb-16 md:pt-32 md:pb-24 lg:py-36 bg-[#ffffff] dark:bg-[#0c1014]">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 mb-12 lg:mb-0 lg:pr-8">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6 hero-headline">
              <span className="text-[#0c1014] dark:text-[#ffffff] mr-2">PetrolJet'le</span> 
              <div className="slogan-container">
                <span 
                  className={`slogan-animation ${isVisible ? 'slogan-visible' : 'slogan-hidden'}`}
                  style={{ color: slogans[currentIndex].color }}
                >
                  {slogans[currentIndex].text}
                </span>
              </div>
            </h1>
            <p className="text-lg sm:text-xl mb-8 text-[#0c1014] dark:text-white max-w-2xl">
              PetrolJet, lokasyonunuzdaki yakıt fiyatlarını karşılaştırır ve istasyonların kampanya ile indirimlerinden yararlanarak tasarruf etmenizi sağlar.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button 
                className="bg-[#eebd32] hover:bg-[#eebd32]/90 text-[#0c1014] rounded-full text-base px-6 py-5 h-auto"
                asChild
              >
                <a href="#features">Hemen Başla</a>
              </Button>
              <Button 
                variant="outline" 
                className="bg-[#0c1014] text-white hover:bg-[#0c1014]/90 dark:bg-white dark:text-[#0c1014] dark:hover:bg-white/90 border-0 rounded-full text-base px-6 py-5 h-auto"
                asChild
              >
                <a href="#contact">Bizimle İletişime Geçin</a>
              </Button>
            </div>
          </div>
          <div className="lg:w-1/2 flex justify-center items-center">
            <div className="relative w-[280px] sm:w-[300px] md:w-[320px] mx-auto lg:mx-0">
              {/* Phone glow effect */}
              <div className="absolute -inset-0.5 bg-gradient-to-tr from-[#eebd32] to-[#c14a1d] opacity-20 blur-xl rounded-[60px]"></div>
              
              {/* iPhone 13 Pro Max mockup */}
              <div className="relative rounded-[54px] overflow-hidden border-[14px] border-[#121917] bg-[#121917] shadow-xl w-full h-auto aspect-[9/19.5]">
                {/* iPhone notch */}
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-1/2 h-7 bg-[#121917] rounded-b-3xl z-10"></div>
                
                {/* Status bar */}
                <div className="absolute top-1 left-5 right-5 flex justify-between items-center z-20 text-[10px] text-white/90">
                  <div>9:41</div>
                  <div className="flex items-center space-x-1">
                    <div>4G</div>
                    <div>100%</div>
                  </div>
                </div>
                
                {/* Placeholder app UI */}
                <div className="relative w-full h-full bg-[#f7f7f7] dark:bg-[#121212] overflow-hidden">
                  {/* App header */}
                  <div className="w-full p-4 bg-[#eebd32] text-[#0c1014] flex items-center">
                    <div className="text-[#0c1014] font-bold text-xl mr-3">PetrolJet</div>
                    <div className="text-[#0c1014]/80 text-xs ml-auto flex items-center">
                      <span>Konum: </span>
                      <span className="font-semibold ml-1">İstanbul</span>
                    </div>
                  </div>
                  
                  {/* App content */}
                  <div className="p-3">
                    <div className="mb-4 p-2">
                      <h3 className="text-[#0c1014] dark:text-white text-sm font-medium">Yakınınızdaki İstasyonlar</h3>
                    </div>
                    
                    {/* Station cards */}
                    <div className="space-y-3">
                      {/* Station 1 */}
                      <div className="bg-white dark:bg-[#222] rounded-xl p-3 shadow-sm">
                        <div className="flex justify-between items-center mb-2">
                          <div className="font-bold text-[#0c1014] dark:text-white">Shell</div>
                          <div className="text-[#c14a1d] text-sm font-bold">1.4 km</div>
                        </div>
                        <div className="flex space-x-2 items-center">
                          <div className="flex-1 text-xs bg-[#f1f1f1] dark:bg-[#333] rounded-lg p-2">
                            <div className="text-[#8e44ad] font-semibold">Dizel</div>
                            <div className="font-bold text-[#0c1014] dark:text-white">36.42 ₺</div>
                          </div>
                          <div className="flex-1 text-xs bg-[#f1f1f1] dark:bg-[#333] rounded-lg p-2">
                            <div className="text-[#cd2033] font-semibold">Benzin</div>
                            <div className="font-bold text-[#0c1014] dark:text-white">37.98 ₺</div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Station 2 */}
                      <div className="bg-white dark:bg-[#222] rounded-xl p-3 shadow-sm">
                        <div className="flex justify-between items-center mb-2">
                          <div className="font-bold text-[#0c1014] dark:text-white">BP</div>
                          <div className="text-[#c14a1d] text-sm font-bold">2.1 km</div>
                        </div>
                        <div className="flex space-x-2 items-center">
                          <div className="flex-1 text-xs bg-[#f1f1f1] dark:bg-[#333] rounded-lg p-2">
                            <div className="text-[#8e44ad] font-semibold">Dizel</div>
                            <div className="font-bold text-[#0c1014] dark:text-white">36.28 ₺</div>
                          </div>
                          <div className="flex-1 text-xs bg-[#f1f1f1] dark:bg-[#333] rounded-lg p-2">
                            <div className="text-[#cd2033] font-semibold">Benzin</div>
                            <div className="font-bold text-[#0c1014] dark:text-white">37.85 ₺</div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Station 3 - with promotion */}
                      <div className="bg-white dark:bg-[#222] rounded-xl p-3 shadow-sm border-2 border-[#eebd32]">
                        <div className="flex justify-between items-center mb-2">
                          <div className="font-bold text-[#0c1014] dark:text-white">Opet</div>
                          <div className="text-[#2ecc71] text-sm font-bold">3.2 km</div>
                        </div>
                        <div className="flex space-x-2 items-center">
                          <div className="flex-1 text-xs bg-[#f1f1f1] dark:bg-[#333] rounded-lg p-2">
                            <div className="text-[#8e44ad] font-semibold">Dizel</div>
                            <div className="font-bold text-[#0c1014] dark:text-white">35.99 ₺</div>
                          </div>
                          <div className="flex-1 text-xs bg-[#f1f1f1] dark:bg-[#333] rounded-lg p-2">
                            <div className="text-[#cd2033] font-semibold">Benzin</div>
                            <div className="font-bold text-[#0c1014] dark:text-white">37.75 ₺</div>
                          </div>
                        </div>
                        <div className="mt-2 bg-[#eebd32]/10 rounded-lg p-2 text-xs text-[#0c1014] dark:text-white">
                          <span className="font-semibold text-[#eebd32]">%5 İndirim:</span> 50₺ ve üzeri alışverişlerde
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}