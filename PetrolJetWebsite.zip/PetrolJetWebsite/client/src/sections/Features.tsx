import { Rocket, Shield, TrendingUp, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: <Rocket className="h-6 w-6 text-[#eebd32]" />,
    title: "Hızlı ve Etkin",
    description: "Optimum hız ve performans ile işlerinizi zamanında tamamlayın."
  },
  {
    icon: <Shield className="h-6 w-6 text-[#eebd32]" />,
    title: "Güvenlik Odaklı",
    description: "En yüksek güvenlik standartları ile verilerinizi koruyoruz."
  },
  {
    icon: <TrendingUp className="h-6 w-6 text-[#eebd32]" />,
    title: "Veri Analizi",
    description: "Detaylı analizlerle işinize yön verin ve stratejinizi geliştirin."
  }
];

export default function Features() {
  return (
    <section id="features" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">Özellikler</h2>
          <p className="section-subheading">
            Petrol Jet'in sunduğu özellikler ile işinizi kolaylaştırın.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="bg-background hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="bg-[#eebd32]/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold">{feature.title}</h3>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <Button 
            variant="link" 
            className="text-[#eebd32] hover:text-[#eebd32]/80 gap-2"
            asChild
          >
            <a href="#how-it-works">
              <span>Nasıl Çalıştığını Öğrenin</span>
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
