import { useState } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqItems = [
  {
    question: "Petrol Jet nasıl çalışır?",
    answer: "Petrol Jet, modern teknolojilerle geliştirilen bir platformdur. Kullanıcı dostu arayüzü ve güçlü altyapısı ile işlerinizi kolaylaştırmak için tasarlanmıştır. Detaylı bilgi için \"Nasıl Çalışır\" bölümünü inceleyebilirsiniz."
  },
  {
    question: "Ücretlendirme nasıl yapılıyor?",
    answer: "Ücretlendirme, seçtiğiniz pakete ve ihtiyaçlarınıza göre değişiklik göstermektedir. KOBİ ve Kurumsal paketlerimiz hakkında detaylı bilgi için bizimle iletişime geçebilirsiniz."
  },
  {
    question: "Teknik destek alabilir miyim?",
    answer: "Evet, tüm müşterilerimize teknik destek sunuyoruz. Kurumsal paket müşterilerimiz 7/24 teknik destek hizmetinden yararlanabilirken, KOBİ paketlerimizde mesai saatleri içerisinde destek sağlıyoruz."
  },
  {
    question: "Özel entegrasyonlar yapılabiliyor mu?",
    answer: "Evet, mevcut sistemlerinizle entegrasyon sağlayabiliyoruz. Özel entegrasyon ihtiyaçlarınız için lütfen bizimle iletişime geçin."
  }
];

export default function Help() {
  return (
    <section id="help" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">Yardım</h2>
          <p className="section-subheading">
            Sıkça sorulan sorular ve yardım dokümanlarımız.
          </p>
        </div>
        
        <div id="faq" className="max-w-3xl mx-auto">
          <h3 className="text-2xl font-semibold mb-6">Sıkça Sorulan Sorular (SSS)</h3>
          
          <Accordion type="single" collapsible className="w-full">
            {faqItems.map((item, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border border-border rounded-lg mb-4 overflow-hidden">
                <AccordionTrigger className="px-4 py-3 hover:bg-muted/50 font-semibold">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4 pt-0 text-muted-foreground">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
