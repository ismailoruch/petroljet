import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";

const commercialPackages = [
  {
    title: "Kurumsal Paket",
    description: "Orta ve büyük ölçekli işletmeler için özel olarak tasarlanmış kapsamlı çözümler.",
    features: [
      "7/24 teknik destek",
      "Gelişmiş raporlama özellikleri",
      "Özel entegrasyon çözümleri"
    ],
    image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "KOBİ Çözümleri",
    description: "Küçük ve orta ölçekli işletmeler için ekonomik ve etkili çözümler.",
    features: [
      "Uygun fiyatlı paketler",
      "Kolay kullanım ve entegrasyon",
      "Ölçeklenebilir yapı"
    ],
    image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500&q=80"
  }
];

export default function Commercial() {
  return (
    <section id="commercial" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">Ticari Çözümler</h2>
          <p className="section-subheading">
            İşletmeniz için özel olarak tasarlanmış ticari çözümlerimiz.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {commercialPackages.map((pkg, index) => (
            <Card key={index} className="overflow-hidden bg-background">
              <div className="h-64 overflow-hidden">
                <img 
                  src={pkg.image}
                  alt={pkg.title} 
                  className="w-full h-full object-cover"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl">{pkg.title}</CardTitle>
                <CardDescription className="text-base">{pkg.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {pkg.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="h-5 w-5 text-[#eebd32] mr-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button 
                  className="bg-[#eebd32] hover:bg-[#eebd32]/90 text-[#0c1014] rounded-full w-full"
                  asChild
                >
                  <a href="#contact">Daha Fazla Bilgi</a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
