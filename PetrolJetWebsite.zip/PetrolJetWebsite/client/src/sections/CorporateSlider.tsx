import { useEffect, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import { ChevronLeft, ChevronRight, Fuel, CreditCard, TrendingUp, Building, Trophy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type SlideType = {
  title: string;
  content: string;
  icon: JSX.Element;
  color: string;
};

const slides: SlideType[] = [
  {
    title: 'İstasyon Sahipleri İçin',
    content: 'İstasyonunuzu PetrolJet ağına ekleyerek müşteri trafiğinizi artırın. Özel kampanyalarınızı yönetin ve daha fazla sürücüye ulaşın.',
    icon: <Building className="h-10 w-10" />,
    color: '#eebd32'
  },
  {
    title: 'Ödeme Entegrasyonu',
    content: 'Akaryakıt ödemelerinizi PetrolJet üzerinden güvenle yapın. Mobil ödeme çözümlerimizle istasyonda beklemeyin.',
    icon: <CreditCard className="h-10 w-10" />,
    color: '#cd2033'
  },
  {
    title: 'Fiyat Rekabeti',
    content: 'Yakıt fiyatlarınızı diğer istasyonlarla karşılaştırın. Rekabetçi fiyatlandırma stratejisi oluşturun ve kâr marjınızı optimize edin.',
    icon: <TrendingUp className="h-10 w-10" />,
    color: '#eebd32'
  },
  {
    title: 'Yakıt Yönetimi',
    content: 'Akaryakıt stok takibi, sipariş yönetimi ve lojistik optimizasyonu ile operasyonel maliyetlerinizi düşürün.',
    icon: <Fuel className="h-10 w-10" />,
    color: '#c14a1d'
  },
  {
    title: 'Sadakat Programları',
    content: 'Müşteri sadakat programları oluşturun. Düzenli müşterilerinize özel indirimler ve kampanyalar sunun.',
    icon: <Trophy className="h-10 w-10" />,
    color: '#cd2033'
  }
];

export default function CorporateSlider() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: 'start' });
  const [canScrollPrev, setCanScrollPrev] = useState(false);
  const [canScrollNext, setCanScrollNext] = useState(true);

  const scrollPrev = () => emblaApi && emblaApi.scrollPrev();
  const scrollNext = () => emblaApi && emblaApi.scrollNext();

  useEffect(() => {
    if (!emblaApi) return;

    const onSelect = () => {
      setCanScrollPrev(emblaApi.canScrollPrev());
      setCanScrollNext(emblaApi.canScrollNext());
    };

    emblaApi.on('select', onSelect);
    emblaApi.on('init', onSelect);

    return () => {
      emblaApi.off('select', onSelect);
      emblaApi.off('init', onSelect);
    };
  }, [emblaApi]);

  return (
    <section className="py-12 bg-[#f9f9f9] dark:bg-[#111a22]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-[#0c1014] dark:text-white mb-2">
            Kurumsal Çözümler
          </h2>
          <p className="text-gray-600 dark:text-gray-300">
            Akaryakıt istasyonu sahipleri ve kurumsal müşteriler için özel çözümler
          </p>
        </div>

        <div className="relative">
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex gap-6">
              {slides.map((slide, index) => (
                <div key={index} className="flex-[0_0_100%] min-w-0 sm:flex-[0_0_50%] md:flex-[0_0_33.333%] lg:flex-[0_0_25%]">
                  <Card className="h-full border-t-4" style={{ borderTopColor: slide.color }}>
                    <CardHeader>
                      <div className="mb-2" style={{ color: slide.color }}>
                        {slide.icon}
                      </div>
                      <CardTitle className="text-lg font-semibold">{slide.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 dark:text-gray-300">{slide.content}</p>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          <Button 
            size="icon" 
            variant="outline"
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 rounded-full bg-white dark:bg-gray-800 shadow-md z-10 h-10 w-10 md:flex hidden"
            onClick={scrollPrev}
            disabled={!canScrollPrev}
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>

          <Button 
            size="icon" 
            variant="outline"
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 rounded-full bg-white dark:bg-gray-800 shadow-md z-10 h-10 w-10 md:flex hidden"
            onClick={scrollNext}
            disabled={!canScrollNext}
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
        </div>

        <div className="flex justify-center gap-2 mt-6 md:hidden">
          <Button 
            size="icon" 
            variant="outline"
            className="rounded-full h-10 w-10" 
            onClick={scrollPrev}
            disabled={!canScrollPrev}
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button 
            size="icon" 
            variant="outline"
            className="rounded-full h-10 w-10"
            onClick={scrollNext}
            disabled={!canScrollNext}
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
        </div>
      </div>
    </section>
  );
}