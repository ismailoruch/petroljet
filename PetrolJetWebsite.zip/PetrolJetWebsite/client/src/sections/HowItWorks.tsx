const steps = [
  {
    number: 1,
    title: "Sisteme Kayıt Olun",
    description: "Hızlı ve kolay kayıt süreciyle başlayın. Sadece birkaç adımda hesabınızı oluşturun."
  },
  {
    number: 2,
    title: "İhtiyaçlarınızı Belirleyin",
    description: "İşiniz için gerekli olan özellikleri seçin ve özelleştirmeleri yapın."
  },
  {
    number: 3,
    title: "Hemen Kullanmaya Başlayın",
    description: "Kurulum tamamlandı! Artık sistemi kullanmaya başlayabilirsiniz."
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="section-heading">Nasıl Çalışır</h2>
          <p className="section-subheading">
            Petrol Jet sistemini kullanmak çok kolay. İşte nasıl çalıştığı.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <img 
              src="https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80" 
              alt="Minimalist interface" 
              className="rounded-lg shadow-lg w-full object-cover"
            />
          </div>
          <div className="md:w-1/2">
            <div className="space-y-8">
              {steps.map((step, index) => (
                <div key={index} className="flex">
                  <div className="flex-shrink-0 mr-4">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#eebd32] text-[#0c1014] font-bold">
                      {step.number}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
